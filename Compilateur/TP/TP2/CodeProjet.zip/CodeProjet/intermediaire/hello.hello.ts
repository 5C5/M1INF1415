**TS(helloworld,null)**
1		program
2		var					type:string, order:1, size:256, step:0
3		static string		value:"Please tell me your name: "
4		static string		value:"Hello, "
