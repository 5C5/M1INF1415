**TS(helloworld,null)**
1		program
2		static string	value:"Hello world!"
