**TS(pgcd,calculpgcd)**
6		arg					mod:const, type:int, order:1, size:2, step:0
7		arg					mod:const, type:int, order:1, size:2, step:2
13		temp 				type:bool, order:1, size:1, step:0
14		temp 				type:bool, order:2, size:1, step:1
15		temp 				type:int, order:3, size:2, step:2
16		temp 				type:int, order:4, size:2, step:4
17		temp 				type:int, order:5, size:2, step:6
18		temp 				type:int, order:6, size:2, step:8
20		label
21		label
22		label
23		label
24		label
25		label
26		label
27		label
