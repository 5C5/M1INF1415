**TS(calculpgcd,null)**
1		program
2		var					type:int, order:1, size:2, step:0
3		var					type:int, order:2, size:2, step:2
4		var					type:int, order:3, size:2, step:4
5		function			type:int, arite:2
8		static string		value:"Saisir la premiere valeur: "
9		static string		value:"Saisir la seconde valeur: "
10		static string		value:"le pgcd de "
11		static string		value:" et de "
12		static string		value:" est "
19		temp 				type:int, order:1, size:2, step:0