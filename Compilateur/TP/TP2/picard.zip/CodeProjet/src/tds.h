#ifndef _TDS_H_
#define _TDS_H_

extern int tableContexte[TAILLE][2];

void ajouterSymbole(int, int, char*);

void ajouterContexte(int, int);

#endif
