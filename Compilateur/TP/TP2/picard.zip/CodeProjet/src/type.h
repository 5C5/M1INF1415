#ifndef TYPE_H
#define TYPE_H

/* Structures de descriptions des types*/
#define TRUE 1
#define FALSE 0

/* Liste des différents types existants :
 * programme; fonction, procedure, type, constante, variable, argument, champ, , valenum, temporaire, etiquette, chaine*/

// Structure de la variable
typedef struct {
	//Nom du type
	char* type;
} s_variable;

// Structure du type
typedef struct {
	//Nom du type
	char* type;
} s_type;

// Structure du programme
typedef struct {
	// Pas de type pour les programmes
	char* type = null;
} s_programme;

// Structure 
typedef struct {
	// Type de retour
	char* type;
	// Nombre d'argumments
	int arite;
} s_fonction

typedef union{
	s_variable* variable;
	s_type* type;
	s_programme* programme;
	s_fonction* fonction;
} symbole;



#endif
